# Capstone project: Bike Chain

## Project Description
This repository contains the code and related files for a project developed capstone II. The project was created for educational purposes only.

## Disclaimer
**This project is strictly for educational purposes only.**  
It was not created, distributed, or used for any commercial purposes.


login credentials:
email: zakhia.tayeh@lau.edu
password: messineymar