const express = require('express');
const authRouter = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const mysql = require('mysql2');
const nodemailer = require('nodemailer');
const crypto = require('crypto');
const mysqlPromise = require('mysql2/promise');

const transporter = nodemailer.createTransport({
    host: 'smtp-mail.outlook.com',
    port: 587,
    secure: false, // true for 465, false for other ports
    auth: {
        user: '', // your SMTP username
        pass: ' '
    }
});

const dbPromise = mysqlPromise.createPool({
    host: 'localhost',
    user: 'root',
    password: 'password',
    database: 'supply_chain'
  });

const db = mysql.createConnection({
    user: 'root',
    host: 'localhost',
    password: 'password',
    database: 'supply_chain',
  })


// Sign in & Sign Up endpoints
authRouter.post('/signin', (req, res) => {
    const { email, password } = req.body;
  
    // Query to join the manager and employee tables and get the user
    db.query('SELECT * FROM manager LEFT JOIN employee ON manager.email = employee.email WHERE manager.email = ? OR employee.email = ?', [email, email], async (error, result) => {
            if (error) {
                console.log(error);
                res.status(500).send({ message: 'Database error' });
                return;
            }
            
        if (result.length > 0) {
            // Compare the provided password with the hashed password in the database
            console.log(result);
            const comparison = await bcrypt.compare(password, result[0].password);
  
            if (comparison) {
                // Assign the role based on the isManager attribute
                const role = result[0].isManager ? 'manager' : 'employee';
                res.send({ message: 'Logged in successfully', role: role });
            } else {
                res.send({ message: 'Wrong password' });
            }
        } else {
          res.send('values Inserted') 
        }
      }
    )
  })




