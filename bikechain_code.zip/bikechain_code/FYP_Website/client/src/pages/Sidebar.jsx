import React from 'react';
import { useState } from "react";
import { Link } from 'react-router-dom';
import { faArrowRight,faArrowLeft, faUsers, faTasks, faClipboardList, faShoppingCart, faTruckLoading, faWarehouse, faHome, faBoxOpen, faCogs, faDashboard, faIndustry } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import '../css/sidebar.css'

import { tokens } from "../sub-theme";

import {oSidebar, Menu, MenuItem } from "react-pro-sidebar";
import { Box, IconButton, Typography, useTheme } from "@mui/material";
// import "react-pro-sidebar/dist/css/styles.css";
import HomeOutlinedIcon from "@mui/icons-material/HomeOutlined";
import PeopleOutlinedIcon from "@mui/icons-material/PeopleOutlined";
import ContactsOutlinedIcon from "@mui/icons-material/ContactsOutlined";
import ReceiptOutlinedIcon from "@mui/icons-material/ReceiptOutlined";
import PersonOutlinedIcon from "@mui/icons-material/PersonOutlined";
import CalendarTodayOutlinedIcon from "@mui/icons-material/CalendarTodayOutlined";
import HelpOutlineOutlinedIcon from "@mui/icons-material/HelpOutlineOutlined";
import BarChartOutlinedIcon from "@mui/icons-material/BarChartOutlined";
import PieChartOutlineOutlinedIcon from "@mui/icons-material/PieChartOutlineOutlined";
import TimelineOutlinedIcon from "@mui/icons-material/TimelineOutlined";
import MenuOutlinedIcon from "@mui/icons-material/MenuOutlined";
import MapOutlinedIcon from "@mui/icons-material/MapOutlined";



function Sidebar({sidebarOpen, setSidebarOpen}){
    var isAdmin = sessionStorage.getItem('isadmin');
    console.log("sidebar admin: " + isAdmin)

    const theme = useTheme();
    const colors = tokens(theme.palette.mode);
    const [isCollapsed, setIsCollapsed] = useState(false);
    const [selected, setSelected] = useState("Dashboard");

    return (

        <div className={`sidebar ${sidebarOpen ? 'open' : 'closed'}`} style={{           }}>
           <button className='sidebar-toggle' onClick={() => setSidebarOpen(!sidebarOpen)}>
                <FontAwesomeIcon icon={sidebarOpen ? faArrowLeft : faArrowRight} />
                </button>
            <nav>
            {/* <Typography
              variant="h6"
              color={colors.grey[300]}
              sx={{ m: "15px 0 5px 20px" }}
              > */}
     {/* <Box
       sx={{
         "& .pro-sidebar-inner": {
           background: `${"#1F2A40"} !important`,
         },
         "& .pro-icon-wrapper": {
           backgroundColor: "transparent !important",
         },
         "& .pro-inner-item": {
           padding: "5px 35px 5px 20px !important",
         },
         "& .pro-inner-item:hover": {
           color: "#868dfb !important",
         },
         "& .pro-menu-item.active": {
           color: "#6870fa !important",
         },
       }}
     >

<Menu>

<MenuItem
                                                    active={selected === "Dashboard"}
                                                    style={{
                                                        color: "#e0e0e0",
                                                    }}
                                                    
                                                    icon={<HomeOutlinedIcon />}
                                                    >
                                                    <Typography>{"Dashboard"}</Typography>
                                                    <Link to={"/"} />
                                                    </MenuItem>
                                                    
                                                    
                                                    </Menu>
                                                    
                                                    </Box> */}


            {/* </Typography> */}
                <ul className="nav-list">
                    <li className="nav-item">
                        <Link className="nav-link" to="/main"><FontAwesomeIcon icon={faHome} /> Home</Link>
                    </li>
                    <li className="nav-item">
                        <Link className="nav-link" to="KPI"><FontAwesomeIcon icon={faDashboard} /> Dashboards</Link>
                    </li>
                    {isAdmin == 1 && (
                        <li className="nav-item">
                        <Link className="nav-link" to="employees"><FontAwesomeIcon icon={faUsers} /> Employees</Link>
                    </li>
                    )}
                    <li className="nav-item">
                        <Link className="nav-link" to="tasks"><FontAwesomeIcon icon={faTasks} /> Tasks</Link>
                    </li>
                    <li className="nav-item">
                        <Link className="nav-link" to="orders"><FontAwesomeIcon icon={faClipboardList} /> Orders</Link>
                    </li>
                    <li className="nav-item">
                        <Link className="nav-link" to="manufacture"><FontAwesomeIcon icon={faIndustry} /> Manufacture</Link>
                    </li>
                    <li className="nav-item">
                        <Link className="nav-link" to="purchases"><FontAwesomeIcon icon={faShoppingCart} /> Purchases</Link>
                    </li>
                    <li className="nav-item">
                        <Link className="nav-link" to="suppliers"><FontAwesomeIcon icon={faTruckLoading} /> Suppliers</Link>
                    </li>
                    <li className="nav-item">
                        <Link className="nav-link" to="warehouses"><FontAwesomeIcon icon={faWarehouse} /> Warehouse</Link>
                    </li>
                    <li className="nav-item">
                        <Link className="nav-link" to="products"><FontAwesomeIcon icon={faBoxOpen} /> Products</Link>
                    </li>
                    <li className="nav-item">
                        <Link className="nav-link" to="parts"><FontAwesomeIcon icon={faCogs} /> Parts</Link>
                    </li>
                    {/* <li className="nav-item">
                        <Link className="nav-link" to="Dashboard"><FontAwesomeIcon icon={faDashboard} /> Dashboard</Link>
                    </li> */}
                    <li className="nav-item">
                        <Link className="nav-link" to="Hardware"><FontAwesomeIcon icon={faDashboard} /> System control</Link>
                    </li>
                </ul>
            </nav>
        </div>
    );
    
//   return (
//     <Box
//       sx={{
//         "& .pro-sidebar-inner": {
//           background: `${"#1F2A40"} !important`,
//         },
//         "& .pro-icon-wrapper": {
//           backgroundColor: "transparent !important",
//         },
//         "& .pro-inner-item": {
//           padding: "5px 35px 5px 20px !important",
//         },
//         "& .pro-inner-item:hover": {
//           color: "#868dfb !important",
//         },
//         "& .pro-menu-item.active": {
//           color: "#6870fa !important",
//         },
//       }}
//     >
//       <Sidebar collapsed={isCollapsed}>
//         <Menu iconShape="square">
          {/* LOGO AND MENU ICON */}
          {/* <MenuItem
            onClick={() => setIsCollapsed(!isCollapsed)}
            icon={isCollapsed ? <MenuOutlinedIcon /> : undefined}
            style={{
              margin: "10px 0 20px 0",
              color:"#e0e0e0",
            }}
          >
            {!isCollapsed && (
              <Box
                display="flex"
                justifyContent="space-between"
                alignItems="center"
                ml="15px"
              >
                <Typography variant="h3" color={"#e0e0e0"}>
                  ADMINIS
                </Typography>
                <IconButton onClick={() => setIsCollapsed(!isCollapsed)}>
                  <MenuOutlinedIcon />
                </IconButton>
              </Box>
            )}
          </MenuItem> */}
{/* 
          {!isCollapsed && (
            <Box mb="25px">
              <Box display="flex" justifyContent="center" alignItems="center">
                <img
                  alt="profile-user"
                  width="100px"
                  height="100px"
                  src={`../../assets/user.png`}
                  style={{ cursor: "pointer", borderRadius: "50%" }}
                />
              </Box>
              <Box textAlign="center">
                <Typography
                  variant="h2"
                  color={"#e0e0e0"}
                  fontWeight="bold"
                  sx={{ m: "10px 0 0 0" }}
                >
                  Ed Roh
                </Typography>
                <Typography variant="h5" color={"#4cceac"}>
                  VP Fancy Admin
                </Typography>
              </Box>
            </Box>
          )} */}
{/* 
          <Box paddingLeft={isCollapsed ? undefined : "10%"}>

                                                    <MenuItem
                                                    active={selected === "Dashboard"}
                                                    style={{
                                                        color: "#e0e0e0",
                                                    }}
                                                    onClick={() => setSelected("Dashboard")}
                                                    icon={<HomeOutlinedIcon />}
                                                    >
                                                    <Typography>{"Dashboard"}</Typography>
                                                    <Link to={"/"} />
                                                    </MenuItem>

            <Typography
              variant="h6"
              color={colors.grey[300]}
              sx={{ m: "15px 0 5px 20px" }}
              >
              Data
            </Typography> */}
            {/* 
            <Item
              title="Manage Team"
              to="/team"
              icon={<PeopleOutlinedIcon />}
              selected={selected}
              setSelected={setSelected}
            />
            <Item
              title="Contacts Information"
              to="/contacts"
              icon={<ContactsOutlinedIcon />}
              selected={selected}
              setSelected={setSelected}
            />
            <Item
              title="Invoices Balances"
              to="/invoices"
              icon={<ReceiptOutlinedIcon />}
              selected={selected}
              setSelected={setSelected}
            />

            <Typography
              variant="h6"
              color={colors.grey[300]}
              sx={{ m: "15px 0 5px 20px" }}
            >
              Pages
            </Typography>
            <Item
              title="Profile Form"
              to="/form"
              icon={<PersonOutlinedIcon />}
              selected={selected}
              setSelected={setSelected}
            />
            <Item
              title="Calendar"
              to="/calendar"
              icon={<CalendarTodayOutlinedIcon />}
              selected={selected}
              setSelected={setSelected}
            />
            <Item
              title="FAQ Page"
              to="/faq"
              icon={<HelpOutlineOutlinedIcon />}
              selected={selected}
              setSelected={setSelected}
            />

            <Typography
              variant="h6"
              color={colors.grey[300]}
              sx={{ m: "15px 0 5px 20px" }}
            >
              Charts
            </Typography>
            <Item
              title="Bar Chart"
              to="/bar"
              icon={<BarChartOutlinedIcon />}
              selected={selected}
              setSelected={setSelected}
            />
            <Item
              title="Pie Chart"
              to="/pie"
              icon={<PieChartOutlineOutlinedIcon />}
              selected={selected}
              setSelected={setSelected}
            />
            <Item
              title="Line Chart"
              to="/line"
              icon={<TimelineOutlinedIcon />}
              selected={selected}
              setSelected={setSelected}
            />
            <Item
              title="Geography Chart"
              to="/geography"
              icon={<MapOutlinedIcon />}
              selected={selected}
              setSelected={setSelected}
            /> */}
    //       </Box>
    //     </Menu>
    //   </Sidebar>
    // </Box>
//   );
}

export default Sidebar;